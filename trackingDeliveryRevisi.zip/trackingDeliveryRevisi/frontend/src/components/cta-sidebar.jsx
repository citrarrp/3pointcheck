// import {Button, CustomFlowbiteTheme, Flowbite} from 'flowbite-react';
// import { useState } from 'react';

// const customTheme = {
//     button: {
//        inner: {
//         base: 'flex item-stretch items-center transition none',
//        },
//        label: 'text-sm font-medium ml-2 w-4 items-center justify-center',
//     },
// };

// export default function CTASidebar() {
//     const [showModal, setShowModal] = useState(false);

//     const handleClick = async () => {
//         setShowModal(true);
//         return;
//     }

//     return (
//         <Flowbite theme={{theme: customTheme}}>
//                     </Flowbite>
//     )
// }