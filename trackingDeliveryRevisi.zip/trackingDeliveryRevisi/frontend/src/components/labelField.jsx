// const [schemaFields, setSchemaFields] = useState([]);

// useEffect(() => {
//   const fetchSchemaFields = async () => {
//     try {
//       const res = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/schema-fields`);
//       const data = await res.json();
//       setSchemaFields(data);
//     } catch (err) {
//       console.error("Failed to fetch schema fields:", err);
//     }
//   };

//   fetchSchemaFields();
// }, []);
