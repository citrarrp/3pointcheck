import LoginForm from "../components/form/login.JSX";

export default function Login() {
  return (
    <div>
      <LoginForm />
    </div>
  );
}
