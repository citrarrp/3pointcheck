import Excel from "../components/excel";
import UpdateForm from "../components/form/update";

// const handleClose = () => {
//   setOpen(false);
// };

export default function Label() {
  return (
    <div>
      <Excel />
      {/* <UpdateForm  /> */}
    </div>
  );
}
