import CustomNotFound from "../components/custom-not-found";

export default function NotFound() {
  return (
    <div>
      <CustomNotFound />
    </div>
  );
}
