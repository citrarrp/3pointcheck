import UpdateForm from "../components/form/update";

export default function UpdateData() {
  return (
    <div>
      <UpdateForm />
    </div>
  );
}
