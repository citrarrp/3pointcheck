import { createContext } from "react";

const LabelContext = createContext(null);

export default LabelContext;

// export const useLabel = () => useContext(LabelContext);
